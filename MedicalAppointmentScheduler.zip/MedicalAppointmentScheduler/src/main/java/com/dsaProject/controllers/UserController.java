package com.dsaProject.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.dsaProject.entities.User;
import com.dsaProject.repositories.UserRepositoy;

@Controller
public class UserController {
	private UserRepositoy userRepositoy;

	@Autowired
	public UserController(UserRepositoy userRepositoy) {
		super();
		this.userRepositoy = userRepositoy;
	}

	@GetMapping("/user-registration")
	public String registerUser(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "UserRegistration";
	}

	@GetMapping("/login")
	public String loginPage(Model model) {
		return "Login";
	}

	@PostMapping("/processUser")
	public String processUser(@ModelAttribute("user") User user, Model model) {
		if (user == null)
			return "error";
		userRepositoy.save(user);
		return "redirect:/Home";
	}
}
